"use strict";

const response = require("../responses/response");
const config = require('../../app.conf.json')

var fonts = {
  Roboto: {
    normal: "fonts/Roboto-Regular.ttf",
    bold: "fonts/Roboto-Medium.ttf",
    italics: "fonts/Roboto-Italic.ttf",
    bolditalics: "fonts/Roboto-MediumItalic.ttf",
  },
};

var PdfPrinter = require("pdfmake");
var printer = new PdfPrinter(fonts);
var fs = require("fs");

exports.CreatePdf = (req, res) => {
  const data = req.body.file;
  var headerColumns = JSON.stringify(data.header.columns)
  const headerr = function(currentPage, pageCount, pageSize) {
      if(currentPage == 1){
          return {}
      }
      if(currentPage == pageCount){
          return {}
      }
      return {
          "columns" : JSON.parse(headerColumns)
        }
  }
  data.header = headerr
  var footerColumns = data.footer.columns
  const footerr = function(currentPage, pageCount, pageSize) {
      if(currentPage == 1){
          return {}
      }
      if(currentPage == pageCount){
          return {}
      }
      return {
          "columns": footerColumns
      }
  }
  data.footer = footerr
  var docDefinition = data;
  const filePath = 'output.txt';

  fs.writeFile(filePath, JSON.stringify(docDefinition), 'utf8', (err) => {
    if (err) {
      console.error('Gagal menyimpan data ke file:', err);
      return;
    }
    console.log('Data berhasil disimpan ke file:', filePath);
  });

  var pdfDoc = printer.createPdfKitDocument(docDefinition);

  var base64 = require("base64-stream");

  var base64stream = pdfDoc.pipe(new base64.Base64Encode());
  pdfDoc.pipe(fs.createWriteStream(config.path_report_file_absolute + "/" + req.body.filename));
  pdfDoc.end();

  var tempFileBase64 = "";

  base64stream.on("data", function(buffer) {
    var part = buffer.toString();
    tempFileBase64 += part;
  });

  base64stream.on("end", function() {
    res.status(200).json({
      data: config.path_report_file_absolute + "/" + req.body.filename,
      // base64 : tempFileBase64
    });
  });

  //let encodedPdf = base64.base64Encode('normal.pdf');

  // console.log(base64stream);
};

// exports.getUsersById = (req, res) => {
//   const id = req.userData.id;
//   const query = `SELECT * FROM users WHERE id = ${id}`;
//   connection.query(query, (error, rows, fields) => {
//     if (error) {
//       return res.send(error);
//     } else {
//       if (rows !== '') {
//         res.status(200).json({
//           status: 201,
//           data: rows
//         });
//       } else {
//         res.status(401).json({
//           status: 404,
//           data: 'Data not found !'
//         });
//       }
//     }
//   });
// };
