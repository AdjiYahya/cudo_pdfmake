const express = require('express');
const router = express.Router();
const pdf = require('../controllers/pdf.js');

router.post('/create', pdf.CreatePdf);
// router.post('/login', usersController.login);

module.exports = router;