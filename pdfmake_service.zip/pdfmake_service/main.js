// require('dotenv').config();
const express = require('express');
const bodyParser = require('body-parser');
const config = require('../app.conf.json')
// const logger = require('morgan');
// const cors = require('cors');

// Auth Middleware
// const checkAuth = require('./middleware/check-auth');

// Routes
const pdf = require('./routes/pdf');

const app = express();

// app.use(cors());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json({limit: '500mb'}));
// app.use(logger('dev'));

// Routing
app.use('/pdf', pdf);

app.listen(process.env.PORT || config.pdfmake_port);
console.log("Pdfmake service started at port " + config.pdfmake_port)
